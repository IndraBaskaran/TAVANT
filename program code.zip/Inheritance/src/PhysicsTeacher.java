class MathsTeacher{
	
	void method1() {
		System.out.println("THIS IS MATHS TEACHER");
		
	}
}
class EnglishTeacher extends MathsTeacher{
	
	void method2() {
		System.out.println("THIS IS ENGLISH TEACHER");
		
	}
}
public class PhysicsTeacher extends EnglishTeacher {

	public static void main(String[] args) {
		PhysicsTeacher obj=new PhysicsTeacher();
		System.out.println("THIS IS PHYSICS TEACHER");
		obj.method1();
		obj.method2();
		
		// TODO Auto-generated method stub

	}

}
