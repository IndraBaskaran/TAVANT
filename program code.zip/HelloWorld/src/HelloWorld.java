
public class HelloWorld {
    public void getMessage() {
    	System.out.println("helloWorld");
    }
	public static void main(String[] args) {
		HelloWorld obj=new HelloWorld();
		obj.getMessage();
		// TODO Auto-generated method stub

	}

}
