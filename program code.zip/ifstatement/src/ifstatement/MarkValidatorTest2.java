package ifstatement;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class MarkValidatorTest2 {

	@Test
	void test() {
		MarkValidator S=new MarkValidator();
		String actual=S.isPass(90);
		String expected="pass";
		assertEquals(actual,expected);
		
	}

}
