package ifstatement;
import java.util.Scanner;
public class MarkValidator {
	public String isPass(int mark) {
		
		if(mark>=40) {
			markGrade(mark);
			return "pass";
			
			
		}
		else
			System.out.println("Fail");
		return "fail";
		
	}
	public String markGrade(int mark) {
		if(mark >90) {
			return "Grade A";
		}
		else if(mark>75){
			return "Grade B";
		}
		else if(mark>60) {
			return "Grade C";
		}
		else
			return "Grade D";
			
			
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MarkValidator obj=new MarkValidator();
		Scanner obj1=new Scanner(System.in);
		int a;
		
		String b,c;
		System.out.println("Enter a number");
		a=obj1.nextInt();
		 b= obj.isPass(a);
              System.out.println("Status of entered mark is"+b);
              if(b=="pass") {
            	  c=obj.markGrade(a);
            	  System.out.println(c);
              }
	
	
		
		
		

	}

}
