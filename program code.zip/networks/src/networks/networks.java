package networks;

public class networks  {
 
  
	public static void main (String[] args) {
		// TODO Auto-generated method stub
          networks obj=new networks();
         wifi obj1=new wifi();
          obj1.performance_wifi();
          
          bluetooth obj2=new bluetooth();
          obj2.performance_bluetooth();
          
	}

}

 class wifi  {
	 double speed;
	 double range;
   void performance_wifi() {
	     System.out.println("THIS IS WIFI!! speed="+"54Mbps" +"and  coverage="+"20meters");
		
	        }
}
class bluetooth  {
	double speed;
	double range;
	void performance_bluetooth() {
		System.out.println("THIS IS BLUETOOTH!!speed"+"25mbps" +"and  coverage="+"100meters");
	}
	
}