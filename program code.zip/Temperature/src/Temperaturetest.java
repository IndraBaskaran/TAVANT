import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;



class Temperaturetest {

	@Test
	void test() {
		Temperature S=new Temperature();
		double actual=S.convertToFarenheit(28.5);
		double expected=60.5;
		assertEquals(actual,expected);
		
	}

}
