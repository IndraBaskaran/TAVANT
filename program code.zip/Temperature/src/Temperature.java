import java.util.Scanner;
public class Temperature {
	public double convertToFarenheit(Double celsius) {
		double c=celsius*(9/5)+32;
		
		return c;
	}
	public double convertToCelsius(Double Farenheit) {
		double d=((Farenheit-32)*5)/9;
		
		return d;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Temperature obj1=new Temperature(); 
		Scanner obj = new Scanner(System.in);
		System.out.println("Enter a number in celsius");
		double a=obj.nextDouble();
		System.out.println("Enter a number in Farenheit");
		double b=obj.nextDouble();
		
		double c=obj1.convertToFarenheit(a);
        double d=  obj1.convertToCelsius(b);
      System.out.println("Celsius is converted into Farenheit="+c);
      System.out.println("Farenheit is converted into Celsius="+d);
	}

}
