import java.util.Scanner;
public class SumOfNumbers {
	int SumOfOddNumber(int x,int y) {
		int res=0,i;
		for(i=x;i<=y;i=i+2) {
			res=res+i;
		}
		return res;
	}
	int SumOfEvenNumber(int x,int y) {
		int res=0,i;
		for(i=x+1;i<=y;i=i+2) {
			res=res+i;
		}
		return res;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SumOfNumbers obj=new SumOfNumbers();
		Scanner obj1=new Scanner(System.in);
		int a,b,x,y;
		System.out.println("Enter two numbers");
		a=obj1.nextInt();
		b=obj1.nextInt();
		x=obj.SumOfOddNumber(a,b);
		y=obj.SumOfEvenNumber(a,b);
        System.out.println("SUM OF ODD NUMBER="+x +"sum of even number="+y);;
	}

}
