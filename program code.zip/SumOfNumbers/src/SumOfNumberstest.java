import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;



class SumOfNumberstest {

	@Test
	void test() {
		SumOfNumbers d=new SumOfNumbers();
		int actual=d.SumOfOddNumber(1,10);
		int expected=25;
		assertEquals(actual,expected);
	}

}
