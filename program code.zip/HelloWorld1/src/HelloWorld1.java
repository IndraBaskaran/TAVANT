
public class HelloWorld1 {

	 public void getMessage() {
	    	System.out.println("HelloWorld");
	    }
		public static void main(String[] args) {
			HelloWorld1 obj=new HelloWorld1();
			obj.getMessage();
			// TODO Auto-generated method stub

		}
}
