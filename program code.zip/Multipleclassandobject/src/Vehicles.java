
public class Vehicles {
	String typeofvehicle="CAR";
	String color="SILVER";
	void battery_vehicle() {
		System.out.println("IF IT BATTERY VEHICLE!!NO NEED TO WORRY ABOUT PETROL/DIESEL");
	}
	void normal_vehicle() {
		System.out.println("IF IT IS NORMAL VEHICLE!!DRIVE FOR LONGER DISTANCE");
	}
	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
Vehicles obj=new Vehicles();
System.out.println("TYPE OF VEHICLE="+obj.typeofvehicle    +"COLOR="+obj.color);
obj.battery_vehicle();
obj.normal_vehicle();

	}

}

