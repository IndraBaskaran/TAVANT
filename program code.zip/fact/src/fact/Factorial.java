package fact;

import java.util.Scanner;

public class Factorial {
          public static int calFact(int x) {
        	  int i,fact=1;
        	  for(i=x;i>0;i--) {
        		  fact=fact*i;
        	  }
        	  return fact;
        	  
          }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner obj1=new Scanner(System.in);
		int a,b;
		System.out.println("Enter a number");
		a=obj1.nextInt();
		
              b= calFact(a);
              System.out.println("Factorial of entered number is"+b);
               
	}

}
