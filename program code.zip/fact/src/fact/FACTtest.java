package fact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class FACTtest {

	@Test
	void test() {
		Factorial s=new Factorial();
		int actual=s.calFact(5);
		int expected=120;
		assertEquals(actual,expected);
	}

}
