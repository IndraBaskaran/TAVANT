package switchstmt;

public class MarkValidator {
public void isPass(int mark) {
		
		if(mark>=40) {
			System.out.println("pass");
			markGrade(mark);
		}
		else
			System.out.println("Fail");
}
	
public void markGrade(int mark) {
	
	int t;
	

	if(mark >90) {
		
		t=1;
	}
	else if(mark>75){
		t=2;
	}
	else if(mark>60) {
		t=3;
	}
	else
		t=4;
		
	
  String markString;
switch(t) {
       case 1:  markString="GRADE A";
                System.out.println(markString);
                break;
       case 2:  markString="GRADE B";
                System.out.println(markString);
                break;
       case 3:  markString="GRADE C";
                System.out.println(markString);
                break;
       case 4:  markString="GRADE D";
                System.out.println(markString);
                break;
        default:break;
}

}
		public static void main(String[] args) {
		int mark=90;
		
		MarkValidator obj=new MarkValidator();
		
		obj.isPass(mark);
		// TODO Auto-generated method stub

	}

}
